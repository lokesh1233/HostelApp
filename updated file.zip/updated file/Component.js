jQuery.sap.declare("OfflineCRUD.Component");
jQuery.sap.require("sap.ui.core.UIComponent");
jQuery.sap.require("sap.ui.core.routing.History");
jQuery.sap.require("sap.m.routing.RouteMatchedHandler");
jQuery.sap.require("OfflineCRUD.util.Formatter");
sap.ui.core.UIComponent.extend("OfflineCRUD.Component", {
	
    metadata : {
        "name" : "OfflineCRUD",
        "version" : "1.1.0-SNAPSHOT",
        "library" : "OfflineCRUD",
      
        "includes" : ["css/style.css"], 
        "dependencies" : {
            "libs" : [ "sap.m", "sap.ui.layout" ],
            "components" : []
        },
    "config" : {
      resourceBundle : "i18n/messageBundle.properties",
      serviceConfig : {
        name: "",
        /*serviceUrl: "/sap/opu/odata/sap/Z_FIORI_DEKITTING_NEW_SRV/"*/
       // serviceUrl : OfflineCRUD.util.Formatter.getServiceUrl()
     //serviceUrl: "../OfflineCRUD/proxy/sap/opu/odata/sap/Z_FIORI_ES_RD_SO_CREATE_SRV/?saml2=disabled"
      }
    },
        routing : {
            config : {
                "viewType" : "XML",
                "viewPath" : "OfflineCRUD.view",
                "targetControl" : "fioriContent", 
                "targetAggregation" : "pages", 
                "clearTarget" : false
            },
      routes : [
        {
          pattern : "",
          name : "S1",
          view : "S1"
        },
        {
            pattern : "AddToCart",
            name : "AddToCart",
            view : "AddToCart"
          },
          {
              pattern : "ConfirmOrder",
              name : "ConfirmOrder",
              view : "ConfirmOrder"
            },
            {
            	pattern : "URLShow",
                name : "URLShow",
                view : "URLShow"
              },
            {
            	  pattern :"NewOrder",
                name : "NewOrder",
                view : "NewOrder"
              },
             
                {
            	  pattern :"ApproveProduct",
                    name : "ApproveProduct",
                    view : "ApproveProduct"
                  },
                {
                	pattern : "ProductDetails",
                    name : "ProductDetails",
                    view : "ProductDetails"
                  },
                  {
                      pattern : "AddModifyProd",
                      name : "AddModifyProd",
                      view : "AddModifyProd"
                      },
                      {
                         pattern : "AddDraftModifyProd_toCart",
                         name : "AddDraftModifyProd_toCart",
                         view : "AddDraftModifyProd_toCart"
                         },
                         
                    {
                    pattern : "eTopupconfirm",
                    name : "eTopupconfirm",
                    view : "eTopupconfirm"
                    },
                    
                    {
                        pattern : "order_hist",
                        name : "order_hist",
                       view : "order_hist"
                    },
                    
                    {
                    	pattern : "Displaydraftdetail",
                        name : "Displaydraftdetail",
                        view : "Displaydraftdetail"
                      },
                      
                      {
                    	  pattern : "DraftProdEditDetail",
                    	  name : "DraftProdEditDetail",
                          view : "DraftProdEditDetail"
                        },
                        
                        {
                            pattern : "DraftEditConfirmOrder",
                            name : "DraftEditConfirmOrder",
                             view : "DraftEditConfirmOrder"
                        },
                        
    
      ]
        }
    },
    createContent : function() {
        var oViewData = {
            component : this
        };

        return sap.ui.view({
            viewName : "OfflineCRUD.view.Main",
            type : sap.ui.core.mvc.ViewType.XML,
            viewData : oViewData
        });
    },
    
    
    init : function() {
        sap.ui.core.UIComponent.prototype.init.apply(this, arguments);
       var sRootPath = jQuery.sap.getModulePath("OfflineCRUD");
      var oServiceConfig = this.getMetadata().getConfig().serviceConfig;
        var sServiceUrl = oServiceConfig.serviceUrl;
        var mConfig = this.getMetadata().getConfig();
        this._routeMatchedHandler = new sap.m.routing.RouteMatchedHandler(this.getRouter(), this._bRouterCloseDialogs);        
        this._initODataModel();        
        var i18nModel = new sap.ui.model.resource.ResourceModel({
            bundleUrl : [ sRootPath, mConfig.resourceBundle ].join("/")
        });
        this.setModel(i18nModel, "i18n");
        this.getRouter().initialize();
    },
    exit : function() {
        this._routeMatchedHandler.destroy();
    },
    setRouterSetCloseDialogs : function(bCloseDialogs) {
        this._bRouterCloseDialogs = bCloseDialogs;
        if (this._routeMatchedHandler) {
            this._routeMatchedHandler.setCloseDialogs(bCloseDialogs);
        }
    },
    _initODataModel : function() {		
    	var model1 = OfflineCRUD.util.Formatter.initOdata(OfflineCRUD.util.Formatter.getServiceUrl(OfflineCRUD.util.Formatter.ESRDCreate));
      //var model2 = OfflineCRUD.util.Formatter.initOdata(OfflineCRUD.util.Formatter.getServiceUrl(OfflineCRUD.util.Formatter.ESRDETopup));
        this.setModel(model1);
       // this.setModel(model2, "model2");
    }
});