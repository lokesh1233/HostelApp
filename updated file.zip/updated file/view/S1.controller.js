jQuery.sap.require("sap.ui.core.mvc.Controller");
jQuery.sap.require("sap.ca.ui.dialog.factory");
jQuery.sap.require("OfflineCRUD.util.daterangevalidationfun");
jQuery.sap.require("OfflineCRUD.util.Formatter");
jQuery.sap.require("sap.m.MessageBox");
jQuery.sap.require("sap.m.MessageToast");
sap.ui.core.mvc.Controller
		.extend(
				"OfflineCRUD.view.S1",
				{
					onInit : function() {
						OfflineCRUD.that=this;
						OfflineCRUD.that.byId("apprid").setVisible(false);
						var online=navigator.onLine;
						if(!online){		
						this.byId("textid").setText("Device is Offline");
						OfflineCRUD.that.opnstore();
						}
						else{
							this.byId("textid").setText("Device is Online");
							OfflineCRUD.that.opnstore();					
						}
						var oView = this.getView();
						this.oModel=this.getOwnerComponent().getModel();						
						this.oTable2 = oView.byId("pushordertabid");
						this.oTable2.setModel(this.oModel);
						oView.byId("idIconTabBarNoIcons").setSelectedKey(
						"pushOrder");
					},
		//Function for openStore			
		opnstore:function(){
		//alert("openStore");
        startTime = new Date();
        updateStatus2("store.open called");
        var properties = {
            "name": "FOSOfflineStore",
            "host": applicationContext.registrationContext.serverHost,			
           "port": applicationContext.registrationContext.serverPort,
            "https": applicationContext.registrationContext.https,
			"serviceRoot" : applicationContext.applicationEndpointURL,
			"streamParams":"custom_header=Authorization:" + authStr + ";",
            "definingRequests" : {
                "PushOrder" : "/PushOrderListSet"
            }
        };  
		
        store = sap.OData.createOfflineStore(properties);		
        store.open(this.openStoreSuccessCallback, errorCallback/*, options*/);
	},
	
	openStoreSuccessCallback:function(){
       var endTime = new Date();
        var duration = (endTime - startTime)/1000;
      //  alert("Store opened in  " + duration + " seconds");
      //  alert("Store is OPEN.");
		var online=navigator.onLine;		
		if(!online){	
		sap.OData.applyHttpClient();
		OfflineCRUD.that.readfun();		//Offline OData calls can now be made against datajs.
		}
		else{
			sap.OData.applyHttpClient();
		}
	},
	
					//Function for Table binding
					readfun:function(){
						var sURL = applicationContext.applicationEndpointURL + "/PushOrderListSet";
						//alert(sURL);
						var oHeaders = {};
						oHeaders['Authorization'] = authStr;
						//oHeaders['X-SMP-APPCID'] = applicationContext.applicationConnectionId;    //this header is provided by the logon plugin           
						request = {
						headers : oHeaders,
						requestUri : sURL,
						method : "GET"
					};
						console.log("read using " + sURL);
						OData.read(request, this.readSuccessCallback, errorCallback);
					},
					
		readSuccessCallback:function(data, response) {			
			 var jsond=new sap.ui.model.json.JSONModel();
						OfflineCRUD.that.oTable2.setModel(jsond);
											OfflineCRUD.that.oTable2
													.bindItems(
															"/results", function(sId, oContext){
															return new sap.m.ColumnListItem(
																	{
																		cells : [
																		       
																				new sap.m.Link(
																						{
																							text : "{OrderNum}",
																							press : [
																									OfflineCRUD.that.presslink,
																									OfflineCRUD.that ]
																						}),
																				new sap.m.Text(
																						{
																							text : "{OrdTypDesc}",
																						}),
																				new sap.m.Text(
																						{
																							text : "{parts:[{path:'CreationDate'}],formatter :'OfflineCRUD.util.Formatter.Date'}",
																							wrapping : false,
																						}),
																				new sap.m.Text(
																						{
																							text : "{parts:[{path:'CustName'},{path:'LocSearch'}],formatter :'OfflineCRUD.util.Formatter.locgroup'}",
																							tooltip:"{CustomerNum}",
																							wrapping : false,
																						}),
																						OfflineCRUD.that.factoryFunction(sId,oContext),
																				new sap.ui.core.Icon(
																						{
																							//src : "{path:'StatusCode',formatter : 'OfflineCRUD.util.Formatter.EditShow'}",
																							color : "#E69A17",
																							//visible:"{path:'OrderType',formatter : 'OfflineCRUD.util.Formatter.EditPush'}",
																							size : "1.5rem",
																							tooltip : "Edit Order Details",
																							press : [
																									OfflineCRUD.that.onEditOrder,
																									OfflineCRUD.that ],
																						}),
																				new sap.ui.core.Icon(
																						{
																							//src : "{path:'StatusCode',formatter : 'OfflineCRUD.util.Formatter.CancelShowpush'}",
																							color : "#FF0000",
																							size : "1.5rem",
																							tooltip : "Order Cancellation",
																							press : [
																									OfflineCRUD.that.onCancelOrder,
																									OfflineCRUD.that ],
																						}), ]
																	});
											
										});
											jsond.setData(data);
			 
        },
        
       //Factory function for changing the template 
        factoryFunction: function(sId,ctx){
			var ind=ctx.getProperty("StatusCode");
			if(ind ==="O"){
		return	 new sap.m.Text({
			text:"{StatusDesc}"
	   
		}).addStyleClass("pind");
		}
	 if(ind ==="L"){
		 return	 new sap.m.Text({
				text:"{StatusDesc}"
		   
			}).addStyleClass("ao");
		 
	 }
	 if(ind==="N"){
		 return	 new sap.m.Text({
				text:"{StatusDesc}"
		   
			}).addStyleClass("oo");
	 }
	 if(ind==="P"){
		 return	 new sap.m.Text({
				text:"{StatusDesc}"
		   
			}).addStyleClass("pfa");
	 }
	 if(ind==="D"){
		 return	 new sap.m.Text({
				text:"{StatusDesc}"
		   
			}).addStyleClass("oc");
	 }
	 if(ind==="B"){
		 return	 new sap.m.Text({
				text:"{StatusDesc}"
		   
			}).addStyleClass("pd");
	 }
	 if(ind==="G"){
		 return	 new sap.m.Text({
				text:"{StatusDesc}"
		   
			}).addStyleClass("dbzd");
	 }
		},
        
        
					// function for formatting calander date function
					datefun : function() {
						var oView = this.getView();
						var curr = new Date();
						var prev_two_months_date = new Date(curr);
						prev_two_months_date.setDate(curr.getDate() - 2);
						var fromDate = prev_two_months_date.toString();
						var inputFrom = OfflineCRUD.util.Formatter
								.Date(fromDate);
						var inputTo = OfflineCRUD.util.Formatter
								.Date(curr);
						this.formDat = OfflineCRUD.util.Formatter
								.Date1(fromDate);
						this.toDat = OfflineCRUD.util.Formatter
								.Date1(curr);
						this.advncesrchdate(inputFrom,inputTo);
					},
					advncesrchdate:function(inputFrom,inputTo){
							OfflineCRUD.frmdte=inputFrom;
							OfflineCRUD.todate=inputTo;
					},
					
					
					// function for Date range restriction
					changeDateFormat : function(evt) {
						var from_date = sap.ui.getCore().byId("stDate")
								.getDateValue();
						var To_date = sap.ui.getCore().byId("toDate")
								.getDateValue();
						var get_From_dateRange = OfflineCRUD.util.daterangevalidationfun
								.date_Range(from_date, To_date);
						var currTime = new Date().getTime();
						var cntDate = sap.ui.getCore().byId("toDate");
						var toDate = sap.ui.getCore().byId("stDate");

						var selectDate = cntDate.getDateValue();
						var selectTime = selectDate.getTime();

						var fromd = cntDate.getDateValue();
						var sel = toDate.getDateValue();

						var toTime = sel.getTime();
						var curr = OfflineCRUD.util.Formatter
								.Date(this.DashboardData.CurrentDate);
						var curenDate = new Date(curr);
						var inputTo = OfflineCRUD.util.Formatter
								.Date(curenDate);
						var prev_two_months_date = new Date();
						prev_two_months_date.setDate(curenDate.getDate() - 2);
						var fd = prev_two_months_date;
						var fromDate = prev_two_months_date.toString();
						OfflineCRUD.util.Formatter.Date(fd);
						var inputFrom = OfflineCRUD.util.Formatter
								.Date(fromDate);
						var date1 = new Date(fromd);
						var date2 = new Date(sel);
						var timeDiff = Math.abs(date2.getTime()
								- date1.getTime());
						var diffDays = Math.ceil(timeDiff / (1000 * 3600 * 24));

						if (selectTime > currTime) {
							sap.m.MessageToast
									.show(
											"To-Date can't be Future Date Selected",
											{
												title : "Info",
												icon : sap.m.MessageBox.Icon.INFORMATION
											});
							cntDate.setDateValue(new Date(inputTo));
						} else if (toTime > currTime) {
							sap.m.MessageToast
									.show(
											"From-Date can't be Future Date Selected",
											{
												title : "Info",
												icon : sap.m.MessageBox.Icon.INFORMATION
											});
							toDate.setDateValue(new Date(inputFrom));
						}

						if (get_From_dateRange === "false1") {
							sap.m.MessageToast
									.show(
											"Select the difference between From-Date and To-Date only 15 days.",
											{
												title : "Info",
												icon : sap.m.MessageBox.Icon.INFORMATION
											});
							cntDate.setDateValue(new Date(inputTo));
							toDate.setDateValue(new Date(inputFrom));
							return;
						}
					},
					
					// for on click on perticular icon tab bar events
					selectIcon : function(evt) {
						var oView = this.getView();
						var myorder = oView.byId("idIconTabBarNoIcons");
						 if(myorder.getSelectedKey() == "pushOrder") {
							if(this.getView().byId("srchpushorder").getValue()!==""){
								this.getView().byId("srchpushorder").setValue();
							}
							this.getView().byId("pageId").setTitle("FOS Order Details");
							OfflineCRUD.that.opnstore();
						}						
					}, 
					
					// F4 for status or orders
					StatusDialog : function(oEvent) {
						var path="/OrderStatusListSet";
						this.StatusDialog = new sap.m.SelectDialog({
							title : "Status",
							growingThreshold : 50,
							noDataText : "No Entries Found",
							items : {
								path : path,
								template : new sap.m.StandardListItem({
									title : "{StatusDesc}",
								})
							},
							liveChange : [ this.StatusDataChange, this ],
							confirm : [ this.StatusDataConfirm, this ],
						});
							this.StatusDialog.setModel(this.oModel);
							this.StatusDialog.open();
					},
					// status confirm
					StatusDataConfirm : function(evt) {
							var oView = this.getView();
							this.StatusData = evt.getParameter("selectedItem")
							.getBindingContext().getObject().StatusType;
						OfflineCRUD.setStatusValue = evt.getParameter("selectedItem")
								.getBindingContext().getObject().StatusDesc;
						sap.ui.getCore().byId("statusId").setValue(OfflineCRUD.setStatusValue);
					},
					// searching status
					StatusDataChange : function(evt) {
						var sValue = evt.getParameter("value").toLowerCase();
						var gtItems = evt.oSource.getItems();
						for (var i = 0; i < gtItems.length; i++) {
							var val1 = gtItems[i].mProperties.title
									.toLowerCase();
							var val2 = gtItems[i].mProperties.description
									.toLowerCase();
							if (val1.indexOf(sValue) > -1
									|| val2.indexOf(sValue) > -1) {
								gtItems[i].setVisible(true);
							} else {
								gtItems[i].setVisible(false);
							}
						}
					},
					// searching data from approval icon tab bar
					SearchData2 : function(oEvent) {
						var oView = this.getView();
						var oTable = oView.byId("SOC_CART_LIST12");
						var sValue = oView.byId("SearchDataId_ap").getValue()
								.toLowerCase();
						var getItems = oTable.getItems();
						for (var i = 0; i < getItems.length; i++) {
							var orderData = getItems[i].getCells()[0].getText()
									.toLowerCase();
							var ry = getItems[i].getCells()[1].getText()
									.toLowerCase();
							var dat = getItems[i].getCells()[2].getText()
									.toLowerCase();
							var dat1 = getItems[i].getCells()[3].getText()
									.toLowerCase();

							if (orderData.indexOf(sValue) > -1
									|| ry.indexOf(sValue) > -1
									|| dat.indexOf(sValue) > -1
									|| dat1.indexOf(sValue) > -1) {
								getItems[i].setVisible(true);
							} else {
								getItems[i].setVisible(false);
							}
						}
					},
					// search field for Push Order Table
					SearchpushData : function(evt) {
						var oView = this.getView();
						var oTable = oView.byId("pushordertabid");
						var sValue = oView.byId("srchpushorder").getValue()
								.toLowerCase();
						var getItems = oTable.getItems();
						for (var i = 0; i < getItems.length; i++) {
							var order = getItems[i].getCells()[0].getText();
							var ry = getItems[i].getCells()[1].getText()
									.toLowerCase();
							var dat = getItems[i].getCells()[2].getText()
									.toLowerCase();
							var dat1 = getItems[i].getCells()[3].getText()
									.toLowerCase();
							var sta = getItems[i].getCells()[4].getText()
									.toLowerCase();
							if (order.indexOf(sValue) > -1
									|| ry.indexOf(sValue) > -1
									|| dat.indexOf(sValue) > -1
									|| sta.indexOf(sValue) > -1
									|| dat1.indexOf(sValue) > -1) {
								getItems[i].setVisible(true);
							} else {
								getItems[i].setVisible(false);
							}
						}
					},
					getRouter : function() {
						return sap.ui.core.UIComponent.getRouterFor(this);
					},
					
					onChange : function(evt) {
						var selcombid = sap.ui.getCore().byId("mysellerlocid");
						var value = selcombid.getValue().toLowerCase();
						// var cominptlength=value.length;
						var combitem = selcombid.getItems();
						var comitemlength = combitem.length;
						var arr = [];
						for (var i = 0; i < comitemlength; i++) {
							var listValue = combitem[i].getText().toLowerCase();
							arr.push(listValue);
						}
						if (arr.indexOf(value) === -1) {
							selcombid.setValueState("Error");
							sap.m.MessageToast.show("Enter Correct Value");
							selcombid.setValue("");
						} else {
							selcombid.setValueState("None");
						}
					},				
					
					backTOS1:function(){
						var icotaid=OfflineCRUD.that.getView().byId("idIconTabBarNoIcons");
						 if (OfflineCRUD.that.statu === undefined) {
							 OfflineCRUD.that.statu = "N";
							}
						 if(icotaid.getSelectedKey()==="pushOrder"){
								OfflineCRUD.that.pushOrderTab(OfflineCRUD.that.statu);
							}
					},
					onRouteMatched : function(oEvent) {
						if (oEvent.getParameter("name") === "S1") {
							if (this.StatusData === undefined) {
								this.StatusData = "N";
							}
							var pushordersrchfiel=this.getView().byId("srchpushorder").getValue();
							 if(pushordersrchfiel!==null && pushordersrchfiel!==""){
								this.getView().byId("srchpushorder").setValue();
								var apptabid=this.getView().byId("pushordertabid");
								for(var i=0;i<apptabid.getItems().length;i++){
									apptabid.getItems()[i].setVisible(true);
								}
							}
						}
					},
					// for searching perticular order after filteration
					searchOrder : function(evt) {
						var from_date = sap.ui.getCore().byId("stDate")
								.getDateValue();
						var To_date = sap.ui.getCore().byId("toDate")
								.getDateValue();
						var retvalue = OfflineCRUD.util.daterangevalidationfun
								.date_Range(from_date, To_date);
						if (retvalue === false) {
							sap.m.MessageToast
									.show(
											"From Date Can't be greater than To Date",
											{
												title : "Info",
												icon : sap.m.MessageBox.Icon.INFORMATION
											});
							return;
						}
						var oView = this.getView();
						var fromdate = sap.ui.getCore().byId("stDate").getValue();
						var todate =   sap.ui.getCore().byId("toDate").getValue();
						this.formDat = OfflineCRUD.util.Formatter
								.Date1(fromdate);
						this.toDat = OfflineCRUD.util.Formatter
								.Date1(todate);
						var myorder = oView.byId("idIconTabBarNoIcons");
						// condition for push order filteration
					/*if (myorder.getSelectedKey()==="approval") {
						this.oTable1.unbindItems();
						
							this._handleBindTable1();
							OfflineCRUD.advsrchfilter.close();
						}
						else */if(myorder.getSelectedKey() === "pushOrder") {
							var userind = "";
							if (this.DashboardData.AgentInd === "S") {
								userind = "X";
							}
							if (this.StatusData === undefined) {
								this.StatusData = "N";
							}
							var path = "/PushOrderListSet?$filter=CustomerNum eq '"
									+ this.DashboardData.CustomerNum
									+ "' and StatusCode eq '" + this.StatusData
									+ "' and FromDate eq datetime'"
									+ this.formDat
									+ "' and ToDate eq datetime'" + this.toDat
									+ "' and AgentInd eq '"
									+ this.DashboardData.AgentInd
									+ "' and UserInd eq '" + userind + "'";
							this.oTable2.unbindItems();
							/*if (this.StatusData === "P") {
								oView.byId("idIconTabBarNoIcons")
								.setSelectedKey("approval");
								
								OfflineCRUD.advsrchfilter.close();
								this._handleBindTable1();
								return;
							}*/
							this.tabledefaultpushbind(path);
							OfflineCRUD.advsrchfilter.close();
							
						} 						
					},
					//for binding approval table
					_handleBindTable1 : function() {
						var oView = this.getView();
						var path;
						var icontabappid = oView.byId("apprid");
						//icontabappid.setCount("0");
						icontabappid.setText("Approvals (0)");
						this.AppStatu = "P";
						this.oTable1.unbindItems();
					
						if (this.DashboardData.IsMainOffice == true
								&& this.DashboardData.AgentInd === "P") {
							var userind = "";
							if (this.DashboardData.AgentInd === "S") {
								userind = "X";
							}
							path = "/OrderListSet?$filter=CustomerNum eq '"
									+ this.DashboardData.CustomerNum
									+ "' and StatusCode eq '" + this.AppStatu
									+ "' and FromDate eq datetime'" + 	this.formDat 
									+ "' and ToDate eq datetime'" +this.toDat 
									+ "' and AgentInd eq '"
									+ this.DashboardData.AgentInd
									+ "' and UserInd eq '" + userind + "'";
						} 
						var that = this;
						this.dialog.open();
						this.oModel
								.read(
										path,
										null,
										[],
										true,
										function(oData, oResponse) {
											if(oData.results.length===0){
												sap.m.MessageToast.show("No data found.");
												that.getView().byId("apprid").setVisible(false);
												that.dialog.close();
												return;
											}
											var jsonmodel = new sap.ui.model.json.JSONModel();
											jsonmodel.setData(oData);
											that.getView().byId("apprid").setVisible(true);
											that.oTable1.setModel(jsonmodel);
											icontabappid.setText("Approvals ("
													+ oData.results.length
													+ ")");
											that.oTable1
													.bindItems(
															"/results",
															new sap.m.ColumnListItem(
																	{
																		type : "Navigation",
																		press : [
																				that.ApproveOrder,
																				that ],
																		cells : [
																				new sap.m.Text(
																						{
																							text : "{OrderNum}",
																							wrapping : false,
																						}),
																				new sap.m.Text(
																						{
																							editable : false,
																							text : "{OrdTypDesc}",
																						}),
																				new sap.m.Text(
																						{
																							text : "{parts:[{path:'CreationDate'}],formatter :'OfflineCRUD.util.Formatter.Date'}",
																							wrapping : false,
																						}),
																			/*	new sap.m.Text(
																						{
																							//text : "{parts:[{path:'CreationDate'}],formatter :'OfflineCRUD.util.Formatter.Date'}",
																							wrapping : false,
																							text : " "
																						}),*/
																				new sap.m.Text(
																						{
																							text : "{parts:[{path:'LocSearch'},{path:'City'}],formatter :'OfflineCRUD.util.Formatter.locgroup'}",
																							wrapping : false,
																						}),
																				new sap.ui.core.Icon(
																						{
																							src : "{path:'Action',formatter : 'OfflineCRUD.util.Formatter.EIndicator'}",
																							color : "#E69A17",
																							size : "1.5rem",
																							tooltip : "Edit Order Details",
																							press : [
																									that.ApproveOrder,
																									that ]
																						}),
																				new sap.ui.core.Icon(
																						{
																							src : "{path:'Action',formatter : 'OfflineCRUD.util.Formatter.EIndicator1'}",
																							color : "#FF0000",
																							size : "1.5rem",
																							tooltip : "Delete Order Details",
																							press : [
																									that.onCancelOrder,
																									that ]
																						}), ]
																	}));
											that.dialog.close();
											
										}, function(oError) {
											that.getView().byId(
													"idIconTabBarNoIcons")
											that.StatusData = "N";
											that.getView().byId(
											"idIconTabBarNoIcons").setSelectedKey("pushOrder");
											that.getView().byId(
											"apprid").setVisible(false);
											that.pushOrderTab(that.StatusData);
											that.dialog.close();
										});
					},
					//approval filter
					filterApproval:function(){
						if(OfflineCRUD.advsrchfilter===undefined){
							OfflineCRUD.advsrchfilter=new sap.ui.xmlfragment("OfflineCRUD.view.AdvanceSearch",this);
						}
						OfflineCRUD.advsrchfilter.open();
						OfflineCRUD.filterind="advncesrchind";
						sap.ui.getCore().byId("statusId").setValue(OfflineCRUD.setStatusValue);
						/*if(OfflineCRUD.setStatusValue==="Pending For Approval"){
							sap.ui.getCore().byId("statusId").setValue(
								"Pending For Approval").setEnabled(false);
								}
						else{*/
							sap.ui.getCore().byId("statusId").setEnabled(true);
						/*}*/
						sap.ui.getCore().byId("stDate").setDateValue(new Date(OfflineCRUD.frmdte));
						sap.ui.getCore().byId("toDate").setDateValue(new Date(OfflineCRUD.todate));
					},
					//approval filter
					onfiltclose:function(){
						OfflineCRUD.advsrchfilter.close();
					},
					//Push Filter function
					pushFilter:function(){
						this.filterApproval();
					},
					
					ApproveOrder : function(evt) {
						var itm = evt.oSource.getBindingContext().getProperty(
								"OrderNum");
						var item1 = evt.getSource().getModel().getProperty(
								evt.getSource().getBindingContext().sPath);
						OfflineCRUD.ApproveProduct=
								{
									OrderNum : itm,
									connectindapprove : item1.OrderType,
						};
						this.getRouter().navTo("ApproveProduct");
					},
					//for showing display data of perticular order
					presslink : function(evt) {
						var icontabdecide=this.getView().byId("idIconTabBarNoIcons");
						if(icontabdecide.getSelectedKey()==="order"){
							this.chk_ind="myordrrurl";
						}
						else{
							this.chk_ind="puhhdrurl";
						}
						var itm = evt.getSource().getParent().getModel()
								.getProperty(
										evt.oSource.getParent()
												.getBindingContext().sPath);
						var odr = itm.OrderNum;
						OfflineCRUD.URLShow=
						{
							OrderNum : odr,
							connectind : itm.OrderType,
							urlpushid:this.chk_ind,
						};
						this.getRouter().navTo("URLShow");
					},
					//edit and change perticular order
					onEditOrder : function(evt) {
						OfflineCRUD.crateind="";
						var icontabdecide=this.getView().byId("idIconTabBarNoIcons");
						if(icontabdecide.getSelectedKey()==="order"){
							this.chkord_ind="myordrrurl";
						}
						else{
							this.chkord_ind="puhhdrurl";
						}
						var itm = evt.getSource().getParent().getModel()
								.getProperty(
										evt.oSource.getParent()
												.getBindingContextPath());
						var odr = itm.OrderNum;
						OfflineCRUD.ProductDetails={
									OrderNum : odr,
									connectind1 : itm.OrderType,
									CustomerNum : this.DashboardData.CustomerNum,
									ind : "Y",
									connectind1 : itm.OrderType,
									chngeodr_ind:this.chkord_ind
								};
						this.getRouter().navTo("ProductDetails");
					},
					
					//cancel  perticular order
					onCancelOrder : function(evt) {
						var that = this;
						OfflineCRUD.that=this;
						this.cancelInd="Not Navigate";
						OfflineCRUD.that=this;
						this.orderNum = evt.getSource().getParent().getModel()
								.getProperty(
										evt.oSource.getParent()
												.getBindingContext().sPath);
						this.orderNum.OrderNum;
						sap.m.MessageBox
								.show(
										"Do you want to delete the Order?",
										{
											title : "Order Cancellation",
											icon : sap.m.MessageBox.Icon.WARNING,
											actions : [ 'Yes', 'No' ],
											onClose : function(oAction) {
												if (oAction == "Yes") {
													var data = {};
													data.ApprvlBlocInd = "";
													data.OrdDeleteInd = "X";
													data.OrderNum = that.orderNum.OrderNum;
													data.CHNGHEADNAV = [ {} ];
													  OfflineCRUD.util.Formatter.showLoader();
													that.oModel
															.create(
																	"/OrdChangeHdrSet",
																	data,
																	{
															        	
															        	async : true,
																		success: function(oData, oResponse) {
																			OfflineCRUD.util.Formatter.hideLoader();
																			var msgCode = [ {
																                code : "ZMOB/266",
																                gaParams : [ {
																                       param3 : "Posted",
																                       param4 : "OrdChangeHdrSet",
																                       param5: "",
																                       path : "My Purchase Order(RD)/S1/Deleted RD Order"
																                } ]
																         } ];
																         that.messageHandling.handleRequestSuccess(oResponse, msgCode,that.backTOS1);
																		},
																		error :function(oError) {
																			OfflineCRUD.util.Formatter.hideLoader();
																			var msgCode = [ {
																                code : "",
																                gaParams : [ {
																                       param3 : "Posted With Error",
																                       param4 : "OrdChangeHdrSet",
																                       param5: "",
																                       path : "My Purchase Order(RD)/S1/Deleted RD Order"
																                } ]
																          } ];
																                that.messageHandling.handleRequestFailure(oError, msgCode, false);
																		}
																	});
												}
											}
										});
					},
					refreshTable1 : function() {
						this.byId("SearchDataId_ap").setValue();
						this.datefun();
						this._handleBindTable1();
					},
					//Push Order refresh
					refreshPushTab : function() {
						this.byId("srchpushorder").setValue();
						this.StatusData = "N";
						this.datefun();
						this.selectIcon();
						this.pushOrderTab(this.StatusData);
						var oView = this.getView();
						/*if (this.DashboardData.AgentInd === "S") {
							oView.byId("statusId").setEnabled(true);
						}*/
					},
					
					addpushcrtion:function(evt){
						 OfflineCRUD.pushfrag=new sap.ui.xmlfragment("OfflineCRUD.view.pushorder",this);
						 OfflineCRUD.pushfrag.open();
						 OfflineCRUD.sellocid= sap.ui.getCore().byId("mypushselid");
						 OfflineCRUD.sellocid.onAfterRendering = function(){
							 if (sap.m.ComboBox.prototype.onAfterRendering) {
					              sap.m.ComboBox.prototype.onAfterRendering.apply(this);
					            }
					            document.getElementById(OfflineCRUD.sellocid.sId+"-inner").disabled=true;
					 		};
						 this.onloc_help();
						 this.onsel_help();
					  }, 
					  onpushClose:function(){
						  	sap.ui.getCore().byId("mypushlocid").setValue("");
							sap.ui.getCore().byId("mypushselid").setValue("");;
							 OfflineCRUD.pushfrag.close();
							 OfflineCRUD.pushfrag.destroy();
					  },
					  onloc_help:function(evt){
						var loccompush = sap.ui.getCore().byId("mypushlocid");
						var path = "/WareHouseListSet?$filter=CustomerNum eq '"
								+ this.DashboardData.CustomerNum + "'";
						var that = this;
						this.oModel.read(path, null, [], false, function(oData,
								oResponse) {
							for (var i = 0; i < oData.results.length; i++) {
								if (oData.results[i].CustomerNum === that.sh) {
									loccompush.setValue(oData.results[i].LocSearch + "-" + oData.results[i].City + "-"
											+ oData.results[i].CustomerNum);
									break;
								}
							}
							if (that.DashboardData.IsMainOffice
									&& that.DashboardData.AgentInd == "P") {
								loccompush.setEditable(true);
							} else {
								loccompush.setEditable(false);
							}
							var jModel = new sap.ui.model.json.JSONModel(
									oData.results);
							loccompush.bindItems("/", new sap.ui.core.Item({
								text : "{LocSearch}-{City}-{CustomerNum}",
							}));
							loccompush.setModel(jModel);
						});
					  },
					  onsel_help:function(){
						var locselcomb=sap.ui.getCore().byId("mypushselid");
						
					  	var path="/OfflineCRUDListSet?$filter=CustomerNum eq '"+this.spcustnum+"'";
					  	this.oModel.read(path,null,[],false,function(oData,oResponse){
					  	var jModel=new sap.ui.model.json.JSONModel(oData.results);
					  		locselcomb.bindItems("/",new sap.ui.core.Item({
					  			text:"{CustomerName}-{LocSearch}-{City}",
					  			tooltip:"{CustomerNum}"
					  		}));
					  		locselcomb.setModel(jModel);
					  	});
					  },
					  onSelselLocation:function(evt){
						var retailcustnum=evt.mParameters.selectedItem;
						this.retailCustomernum=retailcustnum.getBindingContext().getObject().CustomerNum;
					  },
					  
					  onSelectChange:function(evt){
						  var myloccustnum=evt.mParameters.selectedItem;
							this.mylocaCustomernum=myloccustnum.getBindingContext().getObject().CustomerNum;
					  },
					  
					  onpushOk:function(){
							var inputpushselval = sap.ui.getCore().byId("mypushselid")
							.getValue();
					var selinptpushvalue = sap.ui.getCore().byId(
							"mypushselid");
					if (inputpushselval === "" || inputpushselval === null) {
						selinptpushvalue.setValueState("Error");
						sap.m.MessageToast
								.show("Input field can't be blank");
						return;
					} else {
						selinptpushvalue.setValueState("None");
					}
				var inputpushlocvalue = sap.ui.getCore().byId("mypushlocid")
							.getValue();
					OfflineCRUD.retailcustnum = this.retailCustomernum; 
					OfflineCRUD.myloccustnum =inputpushlocvalue
					.substr(inputpushlocvalue.lastIndexOf("-") + 1);
								sap.ui.getCore().byId("mypushlocid").setValue("");
								sap.ui.getCore().byId("mypushselid").setValue("");
								
								OfflineCRUD.AddToCart=
										{
											CustomeNum : this.sh,
											indpush:"pushonaddcart",
											Rfrshind : "X",
										};
								this.getRouter().navTo("AddToCart");
								OfflineCRUD.pushfrag.close();
								OfflineCRUD.pushfrag.destroy();
						  },
						
					//destroy all fragments
					onExit : function() {
						if (this.Busy !== undefined) {
							this.Busy.destroy();
						}
					},
				});