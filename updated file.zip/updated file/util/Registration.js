jQuery.sap.declare("OfflineCRUD.util.registration"); 
debugger;
OfflineCRUD.util.Registration={
regist:function(){		
var appId = "com.jio.fiori.oFT"; // Change this to app id on server
    var applicationContext = null;
    var smpServerProtocol = "http";
    var smpServerHost = "jiosmp3devapp.bss.dev.jio.com";
    var smpServerPort = "8080";
    var authStr = "";
    var store = null; //Offline OData store
    var startTime = null;
    var online = navigator.onLine;

    // Optional initial connection context
    var context = {
         "serverHost": smpServerHost, //Place your SMP 3.0 server name here
         "https": smpServerProtocol == "https",
         "serverPort": smpServerPort,
         "user": "A00660129831",       //user name for registration and the OData Endpoint
         "password": "Welcome.1",   //password for registration and the OData Endpoint
                                     //once set can be changed by calling sap.Logon.changePassword()
         "communicatorId": "REST",
         "passcode": "password",  //note hardcoding passwords and unlock passcodes are strictly for ease of use during development
                                  //once set can be changed by calling sap.Logon.managePasscode()
         "unlockPasscode": "password",
         "passcode_CONFIRM":"password",
         "ssoPasscode":"Password1"
    };

    window.onerror = onError;

    function onError(msg, url, line) {
        var idx = url.lastIndexOf("/");
        var file = "unknown";
        if (idx > -1) {
            file = url.substring(idx + 1);
        }
        alert("An error occurred in " + file + " (at line # " + line + "): " + msg);
        return false; //suppressErrorAlert;
    }
    
    function init() {
		alert("Init Method");
        if (sap.Logger) {
            sap.Logger.setLogLevel(sap.Logger.DEBUG);  //enables the display of debug log messages from the Kapsel plugins.
            sap.Logger.debug("Log level set to DEBUG");
        }
        register()
        console.log("init completed");       
    }
    
    function register() {
	alert("register method");
        updateStatus2("register called");
        sap.Logon.init(logonSuccessCallback, logonErrorCallback, appId, context);
    }
    
    function logonSuccessCallback(result) {
	alert("logonSuccessCallback method");
        console.log("logonSuccessCallback " + JSON.stringify(result));
        updateStatus2("Successfully REGISTERED");
        applicationContext = result;
        //alternatively the authproxy and logon plugincan provide this if SAPKapselHandleHttpRequests=true, (it is by default on iOS)
        authStr = "Basic " + btoa(applicationContext.registrationContext.user + ":" + applicationContext.registrationContext.password);
		alert(authStr);
    }

    function logonErrorCallback(error) {   //this method is called if the user cancels the registration.
       alert("logonErrorCallback method");
	   console.log("An error occurred:  " + JSON.stringify(error));
        if (device.platform == "Android") {  //Not supported on iOS
            navigator.app.exitApp();
        }
    }
    
    function unRegister() {
	alert("unregister method");
        updateStatus2("unregister called");
        sap.Logon.core.deleteRegistration(logonUnregisterSuccessCallback, errorCallback);
        clearTable();
    }

    function logonUnregisterSuccessCallback(result) {
		alert("logonUnregisterSuccessCallback method");
        updateStatus2("Successfully UNREGISTERED");
        console.log("logonUnregisterSuccessCallback " + JSON.stringify(result));
        applicationContext = null;
    }    
        
    function errorCallback(e) {
        alert("An error occurred " + JSON.stringify(e));
        console.log("An error occurred " + JSON.stringify(e)); 
        updateStatus1("");
    }
		}
};