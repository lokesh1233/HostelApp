jQuery.sap.declare("OfflineCRUD.util.daterangevalidationfun");

OfflineCRUD.util.daterangevalidationfun={
date_Range:function(from_date,To_date)
{	var DAte=from_date.getDate();
		var MOnTh=from_date.getMonth();
		var YEaRs=from_date.getFullYear();

		var DAte1=To_date.getDate();
		var MOnTh1=To_date.getMonth();
		var YEaRs1=To_date.getFullYear();
		
		var date=DAte1-DAte;
		var month=MOnTh1-MOnTh;
		var year=YEaRs1-YEaRs;
		
		var total=date+month*30+year*365;
		if(total<0)
			{
			return false;
			}
		else if(total>15)
			{
			return "false1";
			}
		
		return true;
		},

};