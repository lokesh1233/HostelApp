jQuery.sap.declare("OfflineCRUD.util.CustomerData");
OfflineCRUD.util.CustomerData = {
		key : "customer",
		setData : function(customer){
			if (customer) {
				var customer_storage = JSON.stringify(customer);
				sessionStorage.setItem(this.key, customer_storage);
			}
		},
		getData : function(){
			var customer_storage = sessionStorage.getItem(this.key);
			if (customer_storage) {
				customer_storage = JSON.parse(customer_storage);
			}
			if((customer_storage)){
				if ((customer_storage.ZDRDHDRITEMNAV !== undefined)
						&& (customer_storage.ZDRDHDRITEMNAV.results.length > 0)) {
					var itemSet = customer_storage.ZDRDHDRITEMNAV.results;								
					customer_storage.IsMainOffice = true;
					customer_storage.MyCustNum = customer_storage.CustomerNum;
					for(var i = 0; i < itemSet.length; i++){
						if (itemSet[i].CustAddType === "SH") {							
							customer_storage.IsMainOffice = false;
							customer_storage.MyCustNum = itemSet[i].CustomerNum;
							break;
						}
					}
				}
				var oam_remote_user = sessionStorage.getItem("oam_remote_user");
				if(oam_remote_user){
					customer_storage.OAM_REMOTE_USER = oam_remote_user;
				}
			}			
			return customer_storage;
		},
		clearData : function(){
			sessionStorage.removeItem(this.key);
		},
		loadData : function(){
			//Read odata for User Type (ZD, RD, ARD) and User Level (Primary, Secondary)
			var path = "/ZDRDDetHdrSet(CustomerNum='')?$expand=ZDRDHDRITEMNAV";
			var oModel = new sap.ui.model.odata.ODataModel(OfflineCRUD.util.Formatter.getServiceUrl(OfflineCRUD.util.Formatter.SOCreateService), true);
			oModel.setDefaultCountMode(sap.ui.model.odata.CountMode.None);
			oModel.read(path, null, null, false, function(oData, oResponse){
				OfflineCRUD.util.CustomerData.setData(oData);
			}, function(oError){
				OfflineCRUD.util.MessageHandling.handleRequestFailure(oError, true);
			});
		}
};