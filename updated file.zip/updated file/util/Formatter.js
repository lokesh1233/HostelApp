jQuery.sap.declare("OfflineCRUD.util.Formatter");
OfflineCRUD.util.Formatter = {
		/*serviceUrl1: "../PushRd/proxy/sap/opu/odata/sap/Z_FIORI_ES_RD_SO_CREATE_SRV/?saml2=disabled",
		serviceUrl2: "../PushRd/proxy/sap/opu/odata/sap/Z_FIORI_ES_RD_ETOPUP_SRV/?saml2=disabled",*/ 
		initOdata:function(serviceUrl)
		  {
			  var oModel = new sap.ui.model.odata.ODataModel(serviceUrl,true);
			  oModel.setDefaultCountMode(sap.ui.model.odata.CountMode.None);
		      return oModel;			  
		  },
	   ESRDCreate : "Z_FIORI_ES_RD_SO_ETOPUP_OFF_SRV",
	   ESUsage:"Z_FIORI_ES_USAGE_SRV",
	   SOCreateService : "Z_FIORI_ES_SO_CREATE_SRV",
	   serviceUrl : "/sap/opu/odata/sap/@ServiceUrl/",	   
	   proxy : ".." + window.location.pathname + "proxy", 
	   codeOnServer : function(){
		   var regExp = /^localhost$/;//Regular Expression to check host name
		   var hostname = window.location.hostname;
		   return (!regExp.test(hostname));
	   },
	   getServiceUrl : function(service){
	   return ((this.codeOnServer()) ? (this.serviceUrl) : (this.proxy + this.serviceUrl + "?saml2=disabled")).replace("@ServiceUrl", service);
	   },
	   showLoader : function()     {               // for opening dialog
           if(!this.loader) {
                     var xml = "<BusyDialog xmlns='sap.m' />";
                     this.loader = new sap.ui.xmlfragment({
                              fragmentContent : xml
                     }, this);
           }
           this.loader.open();
  },
  receipt_check:function(){
	 
  },
  //function for change status color
  statuscodecolor:function(stuscode){
	  if(stuscode==="O"){
		  if(stuscde==="O"){
			  return "pind";
		  }
	  }
	  
  },
//start for Order history............
  IconViSiblE:function(reS)
  {
       if(reS)
              {
       if(reS.results!==undefined && reS.results.length>0)
              {
       return true;
              }
              } 
        return false;
  },
  
  
  ICON_N:function(ICn)
  {
       if(ICn==="X")
              {
              return "sap-icon://navigation-right-arrow";
              }
       else if(ICn==="Y")
              {
              return "sap-icon://navigation-down-arrow";
              }},
  
               IconTypetooltip:function(val)
                     {
                           if(val=="X")
                                  {
                                  return "Open Invoice Details";
                                  }
                           else if(val=="Y")
                                  {
                                  return "Close Invoice Details";
                                  }
                           },
                           
                           ICO_NSpaceWidth:function(val)
                           {
                           if (val == "X"){
                                return "15px";
                              }else if (val == "Y"){
                                return "15px";
                              }else if (val == undefined){
                                return "45px";
                              }
                           },
                           
                           serialIcon1:function(val){
                                  if(val===undefined)
                                         {
                                         return true;
                                         }
                                         return false;
                                  
                           },
                           
                           DataSetATRUNTime1:function(Ind,Arti,Doc)
                           {
                                  if(Ind!==undefined){
                                         return Arti;
                                         //return Doc;
                                         }else {
                                        	 
                                        	// return Arti;
                                        return parseFloat(Doc);
                                         }
                           },
                         
                           chkdashval:function(Ind,Arti,Doc,rcpt){
                        	   if(Ind!==undefined){
                                   return Arti;
                                   //return Doc;
                                   }
                        	   else if(rcpt===""){
                        		   return parseFloat(Doc);
                        	   }
                        	   else {
                                  	 
                                  	// return Arti;
                                  return rcpt+" / "+parseFloat(Doc);
                                   }
                           },
                           
                           DataSetATRUNTime:function(Ind,Arti,Doc)
                           {
                                  if(Ind!==undefined){
                                       //  return Arti;
                                         return parseFloat(Doc);
                                         }else {
                                        	 return parseFloat(Arti);
                                        // return Doc;
                                         }
                           },
                           changequant:function(val){
                        	   if(val!==undefined){
                        		   return parseFloat(val);
                        	   }
                        	   else{
                        		   return;
                        	   }
                        	  
                           },
                           changequant1:function(val1,val2){
                        	 if(val1==="X" || val1==="Y") {
                        		 return parseFloat(val2);
                        	 } 
                           },
                         /*  
                           DataSetATRUNTime1:function(Ind,Arti,Doc,dispdocnum)
                           {
                                  if(Ind!==undefined){
                                         return Arti;
                                         }else {
                                         return Doc;
                                         }
                           },*/
                           enableLink:function(val1){
                        	   if(val1==="X" || val1==="Y"){
                        		   return false;
                        	   }
                        	   else{
                        		   return true;
                        	   }
                           },
                           //end...............

  
  IconType1: function(val){
	  if (val == "X"){
		      return "sap-icon://media-play";
		    }
	  else if (val == "Y"){
		      return "sap-icon://down";
		  
	  }
	},
	IconSpace_wid: function(val){
		  if (val == "X"){
		      return "5px";
		    }else if (val == "Y"){
		      return "5px";
		    }
		    else if(val=="sp"){
		      return "55px";
		    }
	 },
	 IconSp_w:function(valu){
		if(valu==="sp") {
			return true;
		}
		else{
			return false;
		}
	 },
hideLoader : function() {                         // for closing dialog
           this.loader.close();
  },
	   visible : function(State){
			if(State === "C"){
				return "sap-icon://display";
			}
			return "";
		},
	   locgroup:function(val1,val2){
		   if(val1===""){
			   return val2;
		   }
		   else{
			   return val1+","+val2;
		   }
	   },
	   itemDelindicator:function(val){
		   if(val==="X"){
			   return false
		   }
		   else{
			   return true
		   }
	   },
    EIndicator : function(value) {
    if (value !== "X"){
      return "sap-icon://edit";
    }
    else{
      return "";
    }
  },
  chkvisibility:function(val){
	if(val==="X"){
		return false;
	}  
	else if(val===undefined){
		return true;
	}
	else if(val===""){
		return true;
	}
  },
  pushpullcheck:function(val){
	if(val==="PUSH"){
		return "sap-icon://pull-down";
	}  
	else{
		return;
		//return "sap-icon://pull-down";
	}
  },
  toolpush:function(val){
	  if(val==="PUSH"){
		  return "Push Order";
	  }
	  else{
		  return;
	  }
  },
  visiblecrossButton:function(cross,newchkbox,trmchkbox)
  {
	  if(cross==="ZCM1" || newchkbox!==undefined || trmchkbox==="")
		  {
		  return false;  
		//  return "sap-icon://decline";
		  }
	  else
		  {
		  return true;
		  }	  
  },
  visiblecrss:function(enbledel){
	  if(enbledel){
		  return true;
	  }
	  else{
		  return false;
	  }
  },
  
  deleteRowCopyandEdit:function(itmInd,addexpand){
	  
	  if(itmInd || ( PushRd.crateind==="copyind" && addexpand !== undefined)){
		  return true;
	  }
	  else {
		  return false;
	  }
	  
	  
  },
  
  editableQuantity:function(val1, val2, val3,val4){
	  if(val1=="ZCM1"){
		  return false;
	  }
	  else if(val2=="X"){
		  return false;
	  }
	  else if(val4==="X"){
		  return false;
	  }
	  else if(val4===undefined){
		  return true;
	  }
	  else if(val4===""){
		  return true;
	  }
	  else if(val2 ==="X" && val3==""){
		  return false;
	  }
	  else{
		  return true;
	  }
  },
  
 /* editablecopyquantity:function(val1, val2, val3,val4){
	  if(val1=="ZCM1"){
		  return false;
	  }
	  else if(val2=="X"){
		  return false;
	  }
	  else if(val4==="X"){
		  return false;
	  }
	  else if(val2 ==="X" && val3==""){
		  return false;
	  }
	  else{
		  return true;
	  }
  },*/
  
  
  finalIssueCheck: function(val1,val2){
	  if(val1==="X" && val2===""){
		  return false;
	  }
	  else{
		  return true;
	  }
  },
  
  
  brndLvlbox: function(l){
      if(l==2) return true;
      return false;
 },
      
 setBtHdrVsble: function(l){
      
      if(l==1) return true;
      return false;
      
 },
      
      setBrandVsble: function(l,e){
          if(l==2 && e==false) return false;
          return true;
      },
  visibleIcon: function(v){
		
		/*if(l=="ZSET")return true;
		return false;*/

		if(v==="ZCM1")
			{
			
			return false;
			
			}
		else
			{
			return true;
			}
	},
	newOrdersetIcon:function(va)
	  {
		  if(va)
			{
				return "sap-icon://add";
				
			}
		else
			{
			return "sap-icon://less";
			
			}    
		  
	  },
	  
	  disableBtn:function(val)
	  {
		  debugger;
		if(val)
			return false;
		else 
			return true;
	  },
	  checkBoxc:function(val)
	  {
		  if(val)
			  return true;
		  else
			  return false;
	  },
	passTable_Id:function(val)
	  {
		  
		 this.tabId=val; 
		  
	  },
	 
	  passTable_IdMod:function(val)
	  {
		  
		 this.tabIdMod=val; 
		  
	  },
	  passTable_IdDraft:function(val){
		  this.tabIdDraft=val; 
	  },
	  
	  passmrp_col:function(val){
		this.mrpcol=val;  
	  },
 getmrp_col:function(){
		  return this.mrpcol;
	  },
	  passdeal_col:function(val){
		this.dalcol=val;  
	  },
	  getdel_col:function(){
		  return this.dalcol;
	  },
	  disableCheck:function(val,val2)
	  {
		  if(val2=="X")
			  return false;
		  else 
			  return true;
	  },
	  takeTable_Id:function()
	  {
		  
	return this.tabId;	  
	  },

	  takeTable_IdMod:function()
	  {
		  
	return this.tabIdMod;	  
	  },

	  takeTable_IdDraft:function()
	  {
		  
	return this.tabIdDraft;	  
	  },
	selectionItmIndicator: function(i){
	
		if(i=="") return true;
		return false;
	},
	
	selectionItmIndicator: function(i){
		
		if(i=="") return true;
		return false;
	},
	setIndent: function(i){
		switch(i){
		case "ZSET":
			return "0.5rem";
		case "ZCM1":
			return "2.2rem";
		default:
			return "1.2rem";
		}
	},

	selectionChild: function(i,val){
		if(i==="ZCM1" ){
			return false;
		}
	
		return true;
		
		//return (i=="ZCM1" || !val);
	//	return (i!="ZCM1" && val=="");
	},
	visibleIconforDtl:function(v)
	{
		if(v==="H")
			{
			
			return true;
			
			}
		
			return false;
			
		
	},
	setDetailIcon: function(e){
		if(e)return "sap-icon://add";else return "sap-icon://less";
		
	},
	visibleIconforDt2:function(v,v1)
	{
		if(v==="ZCM1" || v==="ZSIM" && v1==="")
			{
			return false;
			}
		else
			{
			
			return true;
			}
		
	},
	PlaceEnable:function(val,val1){
		if(val==="ZCM1" || val==="ZSIM" && val1===""){
			return "";
		}
		else{
			return "Enter Qty.";
		}
	},
	visibleUom:function(val1,val2,val3){
		if(val1==="ZSIM" && val3==="")
		{
		return "";
		}
	else
		{
		
		return val2;
		}
	},
	chkarticlevalidity:function(val2){
		if(val2==="X"){
			  return 'Error';
		}else{
			return 'None' ;
		}
	},
	
	chkcopyvalidity:function(copyval){
		if(copyval==="X"){
			  return 'Error';
		}
		else if(copyval===undefined){
			return 'None';
		}
		else if(copyval===""){
			return 'None' ;
		}
	},
	
setAddIcon:function(val){
		
		if(val)
		{
			return "sap-icon://add";
			
		}
	else
		{
		return "sap-icon://less";
		
		}
		
	},
	EditShow:function(val)
	{
		if(OfflineCRUD.util.CustomerData.getData().AgentInd==="P" && val=="P")
			{
			return "sap-icon://edit";
			}
		
		if(OfflineCRUD.util.CustomerData.getData().AgentInd==="S" && val==="P"){
			return "sap-icon://edit";
		}
		else
		{
		return "";
		}
	},
	CheckVisibleEdit:function(val,val1){
		if(OfflineCRUD.util.CustomerData.getData().AgentInd==="S" && val=="O")
			{
			return false;
			}
		/*else{
			return true;
		}*/
		/*if(val1 ==="ZJ07" ||  val1 ==="ZFOC" || val1 ==="ZMER")
		{
		return false;
		}*/
		else{
			return true;
		}
	},
	/*EditPush:function(valpush){
		if(valpush ==="ZJ07" ||  valpush ==="ZFOC" || valpush ==="ZMER")
		{
		return false;
		}
		else{
			return true;
		}
	},*/
	CheckCancelEdit:function(val){
		if(val=="O")
		{
		return false;
		}
	else{
		return true;
	}
	},
	CancelShow:function(val)
	{
		if(OfflineCRUD.util.CustomerData.getData().AgentInd==="P" && val=="O"||val=="P")
		{
		return "sap-icon://sys-cancel-2";
		}
		/*else if(val==="G"){
			return "";
				}*/
	else
		{
		return "";
		}
	},
	CancelShowpush:function(valu){
		
		if(valu==="P"){
			return "sap-icon://sys-cancel-2";
		}
		else{
			return "";
		}
		},
		
	setIcon: function(e){
		
		if(e)return "sap-icon://less";
		else return "sap-icon://add";
		
	},
	
setIcon1: function(e){
		
		if(e)return "sap-icon://slim-arrow-down";
		else return "sap-icon://slim-arrow-up";
		
	},
	
	Totaladd:function(val,val1)
	{
	var val2="";
	val2=val*val1;	
	val2=val2.toString();
	 /* if(val2===undefined || val2===""|| isNaN(val2)){
          console.log("Invalid Format");
                   return "";
          }
          val2=Number(val2).toFixed(2);  
          var dec=val2.substring(val2.indexOf("."));
          val2= val2.substring(0,val2.indexOf(".")).toString();
          var lastThree = val2.substring(val2.length-3);
          var otherNumbers = val2.substring(0,val2.length-3);
          if(otherNumbers != '')
                   lastThree = ',' + lastThree;
          val2 = otherNumbers.replace(/\B(?=(\d{2})+(?!\d))/g, ",") + lastThree+dec; */
          return OfflineCRUD.util.Formatter.currencyChange(val2);	 
	
	},
	
 
EIndicator1 : function(value) {
    if (value !== "X"){
      return "sap-icon://sys-cancel-2";
    }
    else{
      return "";
    }
  }, 
  
  selectionDelIndicator: function(val){
	  
	  if(val!="" || val=="Y"){
		  return true;
	  }
	  else if(val==""){
	  return false;
	  }
  },
  visibleStatuC:function(val)
  {
	 if(val) return ""; 
  },
  
  changecl:function(Resonval)
  {
	  if(Resonval!=="")
		  {
		  return "bgColor";
		  }
	  
  },
  
  
  RIndicator : function(value) {
	    if (value === "X"){
	      return "sap-icon://receipt";
	    }
	    else{
	      return "";
	    }
	  }, 
  IconTooltip: function(val){
	  if (val == "ZSET"){
	      return "Expand";
	    }else if (val == "ZCM1"){
	      return "Collapse";
	    }
	    else{
	      return "";
	    }
  },
  IconSpaceWidth: function(val){
	  if (val == "ZSET"){
	      return "5px";
	    }else if (val == "ZCM1"){
	      return "5px";
	    }
	    else{
	      return "30px";
	    }  
  },
  
  IconSpace: function(val){ 
	  if (val == "X"){
	      return false;
	    }else if (val == "Y"){
	      return false;
	    }
	    else{
	      return true;
	    }
	  
  },
 IconType: function(val){
	  if (val == "ZSET"){
	      return "sap-icon://media-play";
	    }else if (val == "ZCM1"){
	      return "sap-icon://down";
	    }
	    else{
	      return "";
	    }
  },
  UoMAdd:function(val,val1)
  {
	 return parseInt(val)+" "+val1;
  },
  hideDataMaster: function(l,e){
		if(l==1 && e == false){
			return false;
		}
		return true;
		
	},
setIndentMasterExpand: function(l){
		
		if(l==1){
			return "0.3rem";
		}else{
			return "0rem";
		}
	},
	

	checkMasterVsble: function(l){
		if(l==1){
			return true;
		}
			return false;
	},
	setProduct: function(l,m1,m2,m3){
		switch(l){
		case 0:
			return m1;
		case 1:
			return m2;
		case 2:
			return m3;
		}
		
		
	},
	checkMasterVsble: function(l){
		if(l==1){
			return true;
		}
			return false;
	},
	
	setProductHdrVsble: function(l){
		if(l==0){
			return true;
		}
		return false;
	},
	
	setProductHdr: function(l,f,c,m){
		if(l==0){
			return f;
		}
		return "";
	},
	
	iconMasterVsble: function(l){
		if(l==0)return true;
		return false;
	},
	setIndentvalue: function(l){
		return "0";
	},
	
  Date1:function(value)
  {
	  var oDateFormat = sap.ui.core.format.DateFormat.getInstance({
			pattern : "yyyy-MM-ddT00:00:00"
		});
		return oDateFormat.format(new Date(value));
  },
  
  Date : function(dtvalue) {
		  var oDateFormat = sap.ui.core.format.DateFormat.getInstance({
				pattern : "dd MMM yyyy"
			});
			return oDateFormat.format(new Date(dtvalue));
	},
	orderhistdatevalidation:function(dtvalue){
		  if(dtvalue!==null || dtvalue===""){
			  var oDateFormat = sap.ui.core.format.DateFormat.getInstance({
					pattern : "dd MMM yyyy"
				});
				return oDateFormat.format(new Date(dtvalue));
		  }
		  else{
			  return ;
		  }
	},
	parseInteger : function(val){
		return parseInt(val);
	},
	 currencyChange:function(val)
     {
         if(val===undefined || val===""|| isNaN(val)){
             console.log("Invalid Format");
                      return "";
             }
             val=Number(val).toFixed(2);  
             var dec=val.substring(val.indexOf("."));
             val= val.substring(0,val.indexOf(".")).toString();
             var lastThree = val.substring(val.length-3);
             var otherNumbers = val.substring(0,val.length-3);
             if(otherNumbers != '')
                      lastThree = ',' + lastThree;
             val = otherNumbers.replace(/\B(?=(\d{2})+(?!\d))/g, ",") + lastThree+dec; 
             return val;	  
     }, 
     currencyChange2:function(val)
     {
    	 if(val===undefined || val===""){
    		 return;
    	 }
    	 var dec=val.substring(val.indexOf("."))
    	val= val.substring(0,val.indexOf("."));
    	  val=val.toString();
    	  var lastThree = val.substring(val.length-3);
    	  var otherNumbers = val.substring(0,val.length-3);
    	  if(otherNumbers != '')
    	      lastThree = ',' + lastThree;
    	  val = otherNumbers.replace(/\B(?=(\d{2})+(?!\d))/g, ",") + lastThree+dec; 
    	  return val;
     },    
// modelpath:"../zehys_zd_ordr/model/"
	  modelpath:"model/"
};