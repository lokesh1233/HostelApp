//MessageHandling  v 0.18
jQuery.sap.declare("OfflineCRUD.util.MessageHandling");
jQuery.sap.require("OfflineCRUD.util.MessagePopover");
jQuery.sap.require("sap.m.MessageBox");
jQuery.sap.require("sap.m.MessageToast");
OfflineCRUD.util.MessageHandling = {

	handleRequestSuccess : function(oResponse, msgCodes, fnRefresh) {
		this.MsgAppVar = {};
		this.MsgAppVar.AppCodes = msgCodes;
		this.response = this.detailMessage(oResponse);
		this.refresh = fnRefresh;
		sap.m.MessageBox.show(this.response.Title, {
			title : "Message",
			icon : this.response.icon,
			actions : [ "Close", "Show Details"],
			initialFocus : "Show Details",
			onClose : function(oAction){
				if(oAction === "Show Details"){
					var oModel = new sap.ui.model.json.JSONModel();
					oModel.setData(OfflineCRUD.util.MessageHandling.response.message);
					var oMessageTemplate = new sap.m.MessagePopoverItem(
							{
								type : "{path:'severity',formatter:'OfflineCRUD.util.MessageHandling.messageType'}",
								title : "{message}"
							});					

					var oMessagePopover1 = new OfflineCRUD.util.MessagePopover({
						items : {
							path : '/',
							template : oMessageTemplate
						},
						afterClose : function(oEvent){
							if(typeof OfflineCRUD.util.MessageHandling.refresh === "function"){
								OfflineCRUD.util.MessageHandling.refresh(OfflineCRUD.util.MessageHandling.response.message);
							}
						}
					});
					
					oMessagePopover1.setModel(oModel);
					oMessagePopover1.openBy(new sap.m.Button());
				}
				else if(oAction === "Close"){
					if(typeof OfflineCRUD.util.MessageHandling.refresh === "function"){
						OfflineCRUD.util.MessageHandling.refresh(OfflineCRUD.util.MessageHandling.response.message);
					}					
				}
			}
		});		
		
		var sDoc = "";
		for(var p = 0; p < this.response.message.length; p++){
			var aDocNos = /[0-9]+/.exec(this.response.message[p].message);
			if(aDocNos instanceof Array){
				if(aDocNos[0] !== undefined){
					sDoc = (sDoc === "") ? aDocNos[0] : "-" + aDocNos[0];
				}				
			}			
		}
		
		var oam_remote_user = "";
		var customer = OfflineCRUD.util.CustomerData.getData();
		if(customer){
			oam_remote_user = (customer.OAM_REMOTE_USER === undefined) ? "": customer.OAM_REMOTE_USER;
		}		
		
		var codes = this.MsgAppVar.AppCodes;
		for(var i = 0; i < codes.length; i++){
			if(this.MsgAppVar.code.indexOf(codes[i].code) > -1){
				for(var j = 0; j < codes[i].gaParams.length; j++){
					var ele = codes[i].gaParams[j];
					this.sendData(sDoc, oam_remote_user, ele.param3, ele.param4, ele.param5, ele.path);
				}				
			}
		}
	},
	messageType : function(val) {
		if (val.toUpperCase() === "SUCCESS") {
			return "Success";
		} else if (val.toUpperCase() === "ERROR") {
			return "Error";
		} else if (val.toUpperCase() === "INFO") {
			return "Information";
		} else if (val.toUpperCase() === "WARNING") {
			return "Warning";
		}
		else return "";
	},
	//JSON validation
	IsJsonString : function(str) {
		try {
			JSON.parse(str);
		} catch (e) {
			return false;
		}
		return true;
	},
	jsonParseValidation : function(svl) {

		return this.IsJsonString(svl) == true ? svl : (function() {
			if (svl.length > 0) {
				var encde = encodeURIComponent(svl);
				return decodeURIComponent(encde.replace(
						/%0D|%0C|%08|%09|%0A|%5C%22|%5C/g, ""));
			}
			return false;
		})();
	},
	//remove duplicates
	removeDuplicates : function(msg) {
		var unique = {}, val, mval, newarr = [];
		$.each(msg, function(item) {
			val = this.message;
			mval = val[val.length - 1] === "." ? val.slice(0, -1) : val;
			if (!unique[mval]) {
				newarr.push(this);
				unique[mval] = this;
			}
		});
		return newarr;
	},	
	// transaction validation
	transactionVldtion : function() {
		var appC = this.MsgAppVar.AppCodes, j = 0;
		for (var i = 0; i < appC.length; i++) {
			if (this.MsgAppVar.code.indexOf(appC[i].code) > -1) {
				++j;
			}
		}
		return this.MsgAppVar.AppCodes.length === j ? true : false;
	},
	detailMessage : function(oResponse) {
		this.MsgAppVar.code = [];
		var messages = [];
		var bSuccess = false;
		if (oResponse.headers instanceof Array) {
			var sapmsg = oResponse.headers['sap-message'];
			if (sapmsg == undefined) {
				console.log("no sap-message is defined");
				bSuccess = false;
			}
			else {
				var svl = oResponse.headers['sap-message'].toString(), rspnseMsg = this.jsonParseValidation(svl);				
				if (rspnseMsg) {
					var msg = JSON.parse(rspnseMsg);
					this.MsgAppVar.code.push(msg.code);
					messages.push(msg);
					if (msg.details instanceof Array) {
						var msgval = msg.details;
						for (var i = 0; i < msgval.length; i++) {
							this.MsgAppVar.code.push(msgval[i].code);
							messages.push(msgval[i]);
						}
						delete messages[0].details;
					}
					messages = this.removeDuplicates(messages);
					bSuccess = this.transactionVldtion();
				}
			}
		} else {
			bSuccess = false;
		}
		return {
			Title : "Transaction Completed" +  ((bSuccess) ? "" : " With Errors"),
			icon : ((bSuccess) ? sap.m.MessageBox.Icon.SUCCESS : ""), 
			message : messages
		};
	},
	//failure message request
	handleRequestFailure : function(oError, msgCodes, bShowMsgToast, oMsgBoxOpts) {
		var msgs = "", ErrormsgArray = [];
		var err = oError.response;
		if (err !== undefined) {
			var respMsg = this.jsonParseValidation(err.body);
			if (respMsg) {
				var errmsg = JSON.parse(respMsg).error;
				msgs = "";
				var msg = errmsg.message.value;
				msg = msg[msg.length - 1] == "." ? msg.slice(0, -1) : msg;
				ErrormsgArray.push(msg);
				msgs = msg + "\n";
				var innererror = errmsg.innererror.errordetails;
				if (innererror !== undefined) {
					for (var i = 0; i < innererror.length; i++) {
						msg = innererror[i].message;
						msg = msg[msg.length - 1] == "." ? msg.slice(0, -1) : msg;
						if (ErrormsgArray.indexOf(msg) == -1) {
							ErrormsgArray.push(msg);
							msgs += innererror[i].message + "\n";
						}
					}
				}
				if (bShowMsgToast === true) {
					sap.m.MessageToast.show(msgs);
				} 
				else {
					var oOptions = {
							title : "ERROR",
							icon : sap.m.MessageBox.Icon.ERROR,
							actions : [ sap.m.MessageBox.Action.OK ]
					};
					if(typeof oMsgBoxOpts === "object"){
						if(typeof oMsgBoxOpts.title === "string"){
							oOptions.title = oMsgBoxOpts.title;
						}
						if(typeof oMsgBoxOpts.icon === "string"){
							oOptions.icon = oMsgBoxOpts.icon;
						}						
						if(typeof oMsgBoxOpts.onClose === "function"){
							oOptions.onClose = oMsgBoxOpts.onClose;
						}
					}
					sap.m.MessageBox.show(msgs, oOptions);
				}				
			}
		}		
		
		var oam_remote_user = "";
		var customer = OfflineCRUD.util.CustomerData.getData();
		if(customer){
			oam_remote_user = customer.OAM_REMOTE_USER;
		}		
		
		if(msgCodes instanceof Array){
			for(var i = 0; i < msgCodes.length; i++){
				for(var j = 0; j < msgCodes[i].gaParams.length; j++){
					var ele = msgCodes[i].gaParams[j];
					this.sendData("", oam_remote_user, ele.param3, ele.param4, ele.param5, ele.path);				
				}
			}
		}
		return msgs;
	},
	sendData : function(docNo, userID, p3, p4, p5, path){
		var data = {};
		if(typeof navigator !== "undefined"){
			if(typeof navigator.language === "string"){
				data.Language = navigator.language;
			}
			if(typeof navigator.platform === "string"){
				data.Platform = navigator.platform;
			}
			if(typeof navigator.userAgent === "string"){
				data.Useragent = navigator.userAgent;
			}
			if(typeof navigator.vendor === "string"){
				data.Vendor = navigator.vendor;
			}
			if(typeof navigator.vendorSub === "string"){
				data.VendorSub = navigator.vendorSub;
			}
		}
		if(typeof screen !== "undefined"){
			if(typeof screen.colorDepth === "number"){
				data.Colordepth = screen.colorDepth.toString();
			}
			if(typeof screen.height === "number"){
				data.Height = screen.height.toString();
			}
			if(typeof screen.orientation !== "undefined"){
				if(typeof screen.orientation.type === "string"){
					data.Orientation = screen.orientation.type;
				}
			}
			if(typeof screen.pixelDepth === "number"){
				data.Pixeldepth = screen.pixelDepth.toString();
			}
			if(typeof screen.width === "number"){
				data.Width = screen.width.toString();
			}
		}
		data.Hash = location.hash;
		data.Host = location.host;
		data.Hostname = location.hostname;
		data.Href = location.href;
		if(typeof location.origin !== "undefined"){
			data.Origin = location.origin;
		}
		else{
			data.Origin = location.protocol + "//" + location.hostname + ":" + location.port;
		}
		data.Port = location.port;
		data.Protocol = location.protocol;
		
		if(typeof sap !== "undefined" && typeof sap.ui !== "undefined" && typeof sap.ui.Device !== "undefined"){
			var device = sap.ui.Device;
			if(typeof device.os !== "undefined"){
				data.Os = device.os.name + " " + device.os.versionStr;
			}
			data.Zsystem = "";
			if(device.system !== undefined){
				for(var sys in device.system){
					if(device.system[sys]){
						data.Zsystem = sys;
						break;
					}
				}
			}			
		}
		data.Field1 = docNo;
		data.Field2 = "";
		data.Field3 = p3;//Posting/Posting With Error
		data.Field4 = p4;//Entityset
		data.Field5 = p5;
		data.Path = path;
		data.OAMUser = userID;
		
		var oModel = new sap.ui.model.odata.ODataModel(OfflineCRUD.util.Formatter.getServiceUrl(OfflineCRUD.util.Formatter.ESUsage), true);
		oModel.setDefaultCountMode(sap.ui.model.odata.CountMode.None);
		oModel.create("/UsageDetailsSet", data, null, function(oData, oResponse){
		},function (oError) {
			OfflineCRUD.util.MessageHandling.handleRequestFailure(oError, "", true);
        });
	}
};